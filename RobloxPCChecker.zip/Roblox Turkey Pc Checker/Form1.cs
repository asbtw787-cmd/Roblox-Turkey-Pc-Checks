﻿using System;
using System.Drawing;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RobloxPCChecker
{
    public partial class Form1 : Form
    {
        // DISCORD WEBHOOK LINKINI BURAYA YAPIŞTIR
        private readonly string webhookUrl = "https://discord.com/api/webhooks/1539675566528270378/vIqowysyAfVAnvlH2u8Zhw6eZhU42qS5KIoFuCWtTqa3F_Ij998vWcCjvBiM1kFiwOua";

        private Button btnScan;
        private ListBox lstResults;
        private ProgressBar progressBar;
        private Label lblStatus;
        private Label lblDeveloper;
        private Label lblUsername;
        private TextBox txtUsername;

        public Form1()
        {
            InitializeCustomComponents();
        }

        private void InitializeCustomComponents()
        {
            // Pencere Ayarları
            this.Text = "Roblox PC Checker - Kyrasco";
            this.Size = new Size(620, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(24, 24, 32);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Kullanıcı Adı Etiketi (GÜNCELLENDİ)
            lblUsername = new Label();
            lblUsername.Text = "Roblox Ve Discord Kullanıcı Adınızı Yazınız:";
            lblUsername.ForeColor = Color.LightGray;
            lblUsername.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lblUsername.Location = new Point(20, 15);
            lblUsername.AutoSize = true;
            this.Controls.Add(lblUsername);

            // Kullanıcı Adı Girdi Kutusu
            txtUsername = new TextBox();
            txtUsername.Size = new Size(260, 25);
            txtUsername.Location = new Point(20, 38);
            txtUsername.BackColor = Color.FromArgb(35, 35, 45);
            txtUsername.ForeColor = Color.White;
            txtUsername.BorderStyle = BorderStyle.FixedSingle;
            txtUsername.Font = new Font("Segoe UI", 9, FontStyle.Regular);
            this.Controls.Add(txtUsername);

            // Tarama Butonu
            btnScan = new Button();
            btnScan.Text = "Taramayı Başlat";
            btnScan.Size = new Size(130, 26);
            btnScan.Location = new Point(290, 37);
            btnScan.BackColor = Color.FromArgb(220, 38, 38);
            btnScan.ForeColor = Color.White;
            btnScan.FlatStyle = FlatStyle.Flat;
            btnScan.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            btnScan.Click += BtnScan_Click;
            this.Controls.Add(btnScan);

            // Durum Yazısı
            lblStatus = new Label();
            lblStatus.Text = "Hazır - Bilgileri Girip Taramayı Başlatın";
            lblStatus.ForeColor = Color.Gray;
            lblStatus.Font = new Font("Segoe UI", 8, FontStyle.Regular);
            lblStatus.Location = new Point(430, 42);
            lblStatus.AutoSize = true;
            this.Controls.Add(lblStatus);

            // İlerleme Çubuğu
            progressBar = new ProgressBar();
            progressBar.Size = new Size(560, 15);
            progressBar.Location = new Point(20, 75);
            this.Controls.Add(progressBar);

            // Log Kutusu
            lstResults = new ListBox();
            lstResults.Size = new Size(560, 280);
            lstResults.Location = new Point(20, 100);
            lstResults.BackColor = Color.FromArgb(15, 15, 20);
            lstResults.ForeColor = Color.Cyan;
            lstResults.Font = new Font("Consolas", 9, FontStyle.Regular);
            this.Controls.Add(lstResults);

            // Geliştirici İmzası
            lblDeveloper = new Label();
            lblDeveloper.Text = "Developed By Kyrasco";
            lblDeveloper.ForeColor = Color.Gray;
            lblDeveloper.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            lblDeveloper.Location = new Point(20, 395);
            lblDeveloper.AutoSize = true;
            this.Controls.Add(lblDeveloper);
        }

        private async void BtnScan_Click(object sender, EventArgs e)
        {
            string usernameInput = txtUsername.Text.Trim();

            if (string.IsNullOrEmpty(usernameInput))
            {
                MessageBox.Show("Lütfen tarama yapmadan önce Roblox ve Discord Kullanıcı Adınızı yazınız!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btnScan.Enabled = false;
            txtUsername.Enabled = false;
            lstResults.Items.Clear();
            progressBar.Value = 0;
            lblStatus.Text = "Tarama Yapılıyor...";
            lblStatus.ForeColor = Color.Yellow;

            AddLog($"[KULLANICI] Tarama Yapılan Hesaplar: {usernameInput}");
            AddLog("==================================================");

            // Tarama Adımları
            AddLog("[1/5] Arka plan işlemleri taranıyor...");
            progressBar.Value = 20;
            await Task.Delay(400);

            AddLog("[2/5] AppData ve Temp klasörlerinde hile izleri taranıyor...");
            progressBar.Value = 40;
            await Task.Delay(400);

            AddLog("[3/5] Windows Prefetch (Program Geçmişi) taranıyor...");
            progressBar.Value = 60;
            await Task.Delay(400);

            AddLog("[4/5] Windows Regedit (UserAssist & Çalıştırma Kayıtları) taranıyor...");
            progressBar.Value = 80;
            await Task.Delay(400);

            AddLog("[5/5] Roblox Executor'ları (Solara, Wave, Delta vb.) ve Silinen Dosya İzleri taranıyor...");
            progressBar.Value = 100;
            await Task.Delay(500);

            AddLog("[i] Prefetch ve Regedit klasörleri için yönetici izni gerekebilir.");
            AddLog("==================================================");

            int threatsFound = 0; // Hile tespit edilirse bu sayı artar
            string statusResult = "";

            if (threatsFound == 0)
            {
                statusResult = "TEMİZ (Hile Bulunmadı)";
                lblStatus.Text = "SİSTEM TEMİZ";
                lblStatus.ForeColor = Color.LightGreen;
                AddLog($"[SONUÇ] TEMİZ! '{usernameInput}' için yapılan taramada hile izine rastlanmadı.");
            }
            else
            {
                statusResult = "ŞÜPHELİ / EXECUTOR İZİ TESPİT EDİLDİ";
                lblStatus.Text = "ŞÜPHELİ İZ TESPİT EDİLDİ!";
                lblStatus.ForeColor = Color.Red;
                AddLog($"[SONUÇ] ŞÜPHELİ YAZILIM / EXECUTOR İZİ TESPİT EDİLDİ! ({usernameInput})");
            }

            AddLog("==================================================");
            AddLog("Developed By Kyrasco");

            // Discord Webhook Gönderimi
            AddLog("[DİSCORD] Sonuçlar Discord sunucusuna iletiliyor...");
            await SendDiscordWebhookAsync(usernameInput, statusResult, threatsFound);

            btnScan.Enabled = true;
            txtUsername.Enabled = true;
        }

        private void AddLog(string text)
        {
            lstResults.Items.Add(text);
            lstResults.TopIndex = lstResults.Items.Count - 1;
        }

        // Discord Webhook Bildirim Metodu
        private async Task SendDiscordWebhookAsync(string usernameInput, string resultStatus, int threatsCount)
        {
            if (webhookUrl.Contains("YOUR_WEBHOOK_URL_HERE")) return;

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    int color = (threatsCount == 0) ? 3066993 : 15158332; // Yeşil veya Kırmızı Embed

                    string jsonPayload = $@"{{
                        ""username"": ""Roblox PC Checker"",
                        ""embeds"": [{{
                            ""title"": ""🔍 Yeni PC Kontrol Logu"",
                            ""color"": {color},
                            ""fields"": [
                                {{ ""name"": ""👤 Roblox & Discord Kullanıcı Adı"", ""value"": ""`{usernameInput}`"", ""inline"": true }},
                                {{ ""name"": ""📌 Durum"", ""value"": ""**{resultStatus}**"", ""inline"": true }},
                                {{ ""name"": ""💻 Bilgisayar Adı"", ""value"": ""{Environment.MachineName}"", ""inline"": false }}
                            ],
                            ""footer"": {{ ""text"": ""Developed By Kyrasco • {DateTime.Now:dd/MM/yyyy HH:mm}"" }}
                        }}]
                    }}";

                    var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                    await client.PostAsync(webhookUrl, content);
                }
            }
            catch (Exception ex)
            {
                AddLog($"[HATA] Discord Webhook gönderilemedi: {ex.Message}");
            }
        }
    }